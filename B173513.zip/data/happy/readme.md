from : https://www.ons.gov.uk/peoplepopulationandcommunity/wellbeing/datasets/measuringnationalwellbeinghappiness

https://www.ons.gov.uk/file?uri=%2fpeoplepopulationandcommunity%2fwellbeing%2fdatasets%2fmeasuringnationalwellbeinghappiness%2fcurrent/happinessfinaltcm77431789.xls

Manually edited to create happiness.csv which have regions of interest.
Happiness is on 0-10 scale. 

regions.txt is a csv file with long and lat 